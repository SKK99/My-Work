/*************************************************************************************************
 **  FILENAME	      : main.c	
 **
 **  DESCRIPTION      : This file defines main function to test application
 ** 
 **
 **  REVISION HISTORY :
 **  
 **  DATE	    NAME		   REFERENCE	    REASON
 **  -------------------------------------------------------------------------------------------
 **  8 Mar 2022     Shankar Karn            Test  	    Creation of the main.c
 **
 **
 **  Copyright @ 2022 Capgemini Engineering All Rights Reserved
 **
 ************************************************************************************************/
/* Include Header files */
# include <header.h>

/* Local Macros */
#define ARGC 3
#define INITIALIZE 0
#define NAME 30
/*******************************************************************
 **  FUNCTION NAME	: main
 **
 **  DESCRIPTION	: To test application
 **
 **  RETURN 		: EXIT_SUCCESS or EXIT_FAILURE
 **
 ******************************************************************/

int main(int argc, char *argv[]) {
	/* Checking Validation of arguments */
	if(argc < ARGC ) {
		printf("No of arguments provided are less\n");
		return EXIT_FAILURE;
	}
	
	FILE *fptr2 = NULL;
	char *name = NULL;
	name = (char *) malloc(NAME*sizeof(char));
	strcpy(name, "");
	char *token = NULL;
	int i = INITIALIZE;
	char *temp = NULL;
	temp = (char *) malloc(NAME*sizeof(char));
	for(i=1; i<argc; i++) {
	       strcpy(temp, argv[i]);
	       token = strtok(temp, ".");
	       strcat(name, token);
	       if(i != argc-1)
			strcat(name, "_");
	       token = NULL;
	}
	strcat(name, ".txt");
	printf("%s\n",name);
	/* Creating or opening output file */
	fptr2 = fopen(name, "wb");
	if(fptr2 == NULL) {
		printf("Output file is failed to open\n");
	}
	/* Thread declaration */
	pthread_t *thread = (pthread_t *) malloc((argc-1) * sizeof(pthread_t));
	int retval;
	for(i=1; i<argc; i++) {
		/* Thread creation */
		retval = pthread_create(&thread[i-1], NULL, process, (void *) argv[i]);
		if(retval != 0) {
			printf("Thread %d creation failed\n",i);
			return EXIT_FAILURE;
		}
	}
	/* Create array of file details structure to store them in array */
	file **f = (file **)malloc((argc-1)*sizeof(file *));
	if(f == NULL)
		return EXIT_FAILURE;
	for(i=1; i<argc; i++) {
		f[i] = (file *)malloc(sizeof(file));
		if(f[i] == NULL)
			return EXIT_FAILURE;
		/* Join threads */
		pthread_join(thread[i-1], (void **)&f[i]);
		printf("File details is \n");
		printf("File name %s  char count %d  word count%d\n", f[i]->fname, f[i]->charcount, f[i]->wordcount);
		/* Write into the file */
		fwrite(f[i], sizeof(file), 1, fptr2);
		if(fwrite != 0 )
			printf("written file\n");
		else
			printf("Error in writing file\n");
	}
	/* Free all the memory */
	for(i=1; i<argc; i++){
		free(f[i-1]);
	}
	free(f);
	free(name);
	free(temp);
	fclose(fptr2);	
	free(thread); 
	return EXIT_SUCCESS;
}
