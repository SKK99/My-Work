/*************************************************************************************************
 **  FILENAME	      : source.c	
 **
 **  DESCRIPTION      : This file defines functions of three functions as three thread 
 **			processes that will be cancelled and detached according to scenarios
 ** 
 **
 **  REVISION HISTORY :
 **  
 **  DATE	    NAME		   REFERENCE	    REASON
 **  -------------------------------------------------------------------------------------------
 **  8 Mar 2022     Shankar Karn             Test          Creation of the source.c
 **
 **
 **  Copyright @ 2022 Capgemini Engineering All Rights Reserved
 **
 ************************************************************************************************/

# include <header.h>
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
/*******************************************************************
 *   FUNCTION NAME      : process
 * 
 *   DESCRIPTION        : Thread function
 *   
 *   RETURN             : void *
 *      
 *  ******************************************************************/
void *process(void *arg) {
	char *name = (char *) malloc(sizeof(char));
	strcpy(name, (char *)arg);
	file *f = NULL;
	f = (file *)malloc(sizeof(file));
	pthread_mutex_lock(&mutex);
	f = readWrite(name);
	pthread_mutex_unlock(&mutex);
	printf("\nFILE %s",name);
	return (void *)f;
}
/*******************************************************************
 *   FUNCTION NAME      : readWrite
 * 
 *   DESCRIPTION        : Function that returns file name, character count and word count from a file to a structure
 *   
 *   RETURN             : file *
 *      
 *  ******************************************************************/
file* readWrite(char *name) {
	printf("Reading from file\n");
	FILE *fp = fopen(name, "r");
	file *f = NULL;
	int characters, words, lines;

	if(fp == NULL) {
		printf("Cannot open file\n");
		return NULL;
	}
	
	characters = words = lines = 0;
	char ch;
    	while ((ch = fgetc(fp)) != EOF)
    	{
        	characters++;

        	/* Check new line */
        if (ch == '\n' || ch == '\0')
            lines++;

        /* Check words */
        if (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\0')
            words++;
    }

    /* Increment words and lines for last word */
    if (characters > 0)
    {
        words++;
        lines++;
    }
	/* Store the result into the structure */
	f = (file *) malloc(sizeof(file));
	if(f == NULL)
		return NULL;
	f->fname = (char *) malloc(sizeof(char));
	strcpy(f->fname, name);
	f->charcount = characters;
	f->wordcount = words;
	printf("\n wc %d cc %d\n",words, characters);
	return f;
}
