/*Protype of functions*/
int countWords(char str[]);
char** extractWords(char str[]);
int findReplace(char* str);
void displayWords(char *str);
int freeMemory(char *);
void findReplaceAll(char str[]);
void display(char **ptr,int n);
