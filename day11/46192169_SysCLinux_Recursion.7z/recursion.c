/* @file recursion.c
 * @brief Function Definition for the console driver
 * @author Shankar Karn
 *
 * */
#include <stdio.h>
#include "recursion.h"
#define ZERO 0
#define INIT -1
/*Recursive function to search x in arr[] 
 *Approach : The idea is to compare x with the last element in arr[].
 	     If an element is found at the last position, return it.
	     Else recur recursiveLinearSearch(0 for remaining array and element x.
 */
int recursiveLinearSearch(int arr[], int n, int x) {
	int res = INIT;			/*To store index*/
	n--;				/*Reduce the size to use this variable as last index*/

	if(n>=0) {
		if(arr[n] == x)		
			return n;
		else
			res = recursiveLinearSearch(arr, n, x);
	}
	else
		return -1;
	return res;
}
