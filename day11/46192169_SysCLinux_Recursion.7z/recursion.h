/* @file recusion.h
 * @author Shankar Karn
 * @brief Function contains the prototypes for the console driver
 * */

int recursiveLinearSearch(int arr[], int n, int x);
