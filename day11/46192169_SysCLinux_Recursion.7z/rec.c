/* @file rec.c
 * @brief A console driver
 * @author Shankar Karn
 *
 */
#include <stdio.h>
#include "recursion.h"
#define N 20
#define ZERO 0

int main(int argc, char *argv[]) {
	int arr[N];				/*Array elements*/
	int n = ZERO;				/*Size of array*/
	int index = ZERO;			/*Store the returned index*/
	int x = ZERO;				/*Element to be searched*/
	int i = ZERO;				/*Loop variable*/
	printf("Enter the size of the array\n");
	scanf("%d",&n);
	printf("Enter the array elements\n");
	for( ; i<n; i++) {
		scanf("%d",&arr[i]);
	}
	printf("Enter the key to search\n");
	scanf("%d",&x);
	index = recursiveLinearSearch(arr, n, x);
	if(index != -1) {
		printf("Element %d is present at index %d\n",x,index);
	}
	else {
		printf("Element %d is not present\n",x);
	}
	return 0;
}

