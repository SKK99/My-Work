/****************************************************************************
*
*     FILENAME       :    main.c
*
*     DESCRIPTION    :    This file defines the main function.
*       It is used for performing different operations on a stack.
*
*     Revision History    :
*     DATE              NAME                  REFERENCE            REASON
*     ----------------------------------------------------------
*     09-03-2022        Shankar Karn            Main function       Stack Assignment

*     Copyright @ 2022 Capgemini  All Rights Reserved
*
****************************************************************************/

#include "header.h"

/******************************************************************************
*
*     FUNCTION NAME   :    main
*
*     DESCRIPTION     :    This function calls different functions to perform
*                       operations like insertion, deletion, display etc on
*                       a stack.
*
*     RETURNS         : SUCCESS
*
*******************************************************************************/
int main(int argc, char *argv[])
{
    int stack[STACKSIZE];
    int top;
    int ret;
    int num;
    int choice;

 /* Take the user's choice and invoke the function to perform an operation on 
    stack*/
    top = END;
 
    do
    {
        printf("\nPlease Enter your choice \n");
        printf("\n1.Push \n");
        printf("2.Pop \n");
        printf("3.Display\n");
        printf("4.Peep\n");
        printf("5.Exit\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1: 
                   /* Perform insertion in the stack */
                printf("\nenter the value to be inserted ");
                scanf(" %d",&num);
                ret = push(stack ,&top, num);
                if (SUCCESS == ret)
                {
                   printf("\nItem %d pushed successfully on stack\n", num);
                }
                else
                {
                   printf("\nPush operation failed on stack\n");
                }
                break;

            case 2: 
                /* Perform deletion on the stack */
                ret = pop(stack, &top);
                if (FAILURE != ret)
                {
                    printf("\nItem Popped is %d \n",ret);
                }
                else
                {
                    printf("\nPop operation failed\n");
                }
                break;
            case 3: 
                /* Display the stack contents */
                display(stack, top);
                break;
            case 4: 
                /* Perform deletion on the stack */
                ret = peep(stack, top);
                if (FAILURE != ret)
                {
                    printf("\nItem on top of stack is %d \n",ret);
                }
                else
                {
                    printf("\nPop operation failed\n");
                }
                break;   
            case 5:
                printf("\nProgram ended successfully\n");
                break;
            default:
                printf("\nInvalid Choice\n"); 
                break;
        }
    }while(choice !=5);
    return SUCCESS;
}
