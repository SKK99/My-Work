
/*******************************************************************************
*
*     FILENAME       :    header.h
*
*     DESCRIPTION    :    This file defines the macros and the array for the
*                       stack for array implementation.
*
*     Revision History    :
*     DATE        NAME                  REFERENCE            REASON
*   09-03-2022    Shankar Karn          Header file         Stack Assignment  
    ----------------------------------------------------------
*
*     Copyright @ 2022 Capgemini  All Rights Reserved
*
*******************************************************************************/

/********************** Header File Inclusions ********************************/
#include <stdio.h>

/********************** Macro definitions *************************************/
# define SUCCESS 1
# define FAILURE 0
# define STACKSIZE 10
# define END -1
# define START 0

/********************** Function Declaration **********************************/
int isempty(int);
int overflow(int);
int push(int [], int *, int);
int pop(int [], int *);
int peep(int [], int);
void display(int [], int);
