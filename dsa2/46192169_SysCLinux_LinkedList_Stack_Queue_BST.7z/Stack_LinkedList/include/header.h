/*******************************************************************************
*
*     FILENAME      :    header.h
*
*     DESCRIPTION   :    This file defines the macros and the structure of the
*                       node used for the queue.
*
*     Revision History    :
*     DATE          NAME                  REFERENCE            REASON
*     ----------------------------------------------------------
*     09-03-2022    Shankar Karn           Header file          Stack with linked list
*     Copyright @ 2022 Capgemini  All Rights Reserved
*
*******************************************************************************/

/********************** Header File Inclusions ********************************/
#include <stdio.h>
#include <stdlib.h>

/********************** Macro definitions *************************************/
# define SUCCESS 1
# define FAILURE 0

/********************** Structure Definition **********************************/
typedef struct s_node
{
    int data;
    struct s_node *next;
}node;

/********************** Function Declaration **********************************/
int push(node **, int);
int pop(node **);
int peep(node **);
int isempty(node *);
void display(node **);
int free_stack(node **);

