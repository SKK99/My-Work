/*******************************************************************************
*
*     FILENAME       :    functions.c
*
*     DESCRIPTION    :    This file defines the various functions on stack.
*
*     Revision History    :
*     DATE              NAME                  REFERENCE            REASON
*     ----------------------------------------------------------
*     09-03-2022    Shankar Karn        Function definitions    Stack with Linked List
*
*       Copyright @ 2022 Capgemini  All Rights Reserved
*******************************************************************************/

#include "header.h"

/*****************************************************************************
*     FUNCTION NAME   :   isempty
*
*     DESCRIPTION   :   This function checks whether the stack is empty or not
*
*     RETURNS         : SUCCESS, if stack is empty
*                       FAILURE, if stack is not empty
*****************************************************************************/
int isempty(node *top) /* Parameter for the front end of the stack */
{
    if (NULL == top)
    {
        return SUCCESS;
    }
    else
    {
        return FAILURE;
    }
}

/**************************************************************************
*     FUNCTION NAME : push
*
*     DESCRIPTION   :This function pushes a new node at the top of the stack
*
*     RETURNS       :SUCCESS/FAILUE
*
*****************************************************************************/
int push(node **top, int value) 
{
    node *newnode;      /*Node pointer for the new node to be inserted */

    /* Allocate memory to the new node */
    newnode = (node*) malloc (sizeof(node));

    /* Check if memory is allocated or not */
    if (NULL ==newnode)
    {
        printf("Memory not available");
        return FAILURE;
    }

    /* Insert the new node in the stack */
    newnode->data = value;
    newnode->next = NULL;

       /* Check whether stack is empty or not */
    if (isempty(*top))
    {
       newnode->next = NULL;
    }
    else
    {
        /* Node's exist in the stack so insert at the top end */
        (newnode)->next = *top;
    }
    *top = newnode;
    return SUCCESS;

}

/***************************************************************************
*  FUNCTION NAME : pop
*
*  DESCRIPTION   :  This function deletes a node from the top of the stack
*
*  RETURNS      : SUCCESS, if element is deleted
*	          FAILURE, if stack is empty
*
*****************************************************************************/
int pop(node **top)
{
    node *temp_node; /* Temporary node pointer */
    int value;      /* Variable to represent the data which is deleted */
    
    /* Check if the stack is empty or not */     
    if (isempty(*top))
    {
        printf("\nStack Underflow");
        return FAILURE;
    }
 
    temp_node = *top;
    *top = (*top)->next;

    value = temp_node->data;
    free (temp_node);
    printf("\nElement deleted is %d",value);
    return SUCCESS;
}

/***************************************************************************
*  FUNCTION NAME : peep
*
*  DESCRIPTION   : This function reads a node from the top of the stack
*
*  RETURNS      : SUCCESS, if element is read
*	          FAILURE, if stack is empty
*****************************************************************************/
int peep(node **top)
{
    node *temp_node;    /* Temporary node pointer */
    int value;          /* Variable to represent the data which is deleted */
    
    /* Check if the stack is empty or not */     
    if (isempty(*top))
    {
        printf("\nStack Underflow");
        return FAILURE;
    }
 
    temp_node = *top;

    value = temp_node->data;
    printf("\nElement at top is %d",value);
    return SUCCESS;
}

/******************************************************************************
*
*     FUNCTION NAME   :    display
*
*     DESCRIPTION     :    This function displays the data in the stack
*
*     RETURNS         : void
*
*******************************************************************************/
void display(node **top) /* Parameter for the front end of the stack */
{
    node *current; /* Temporary node pointer to traverse the stack */

    /* Check if the stack is empty or not */
    if (isempty(*top))
    {
        printf("\nThe stack is empty") ;
    }
    else
    {
        printf("\nstack is \n");
  
        /* Traverse the stack and display the elements */
        for( current = *top ; current != NULL ; current = current->next)
        {
            printf("%d -> ",current->data);
        }
        printf("NULL\n");
    }
}

/*****************************************************************************
*     FUNCTION NAME :    free_stack
*
*     DESCRIPTION   :    This function frees the memory which is allocated to
*                       the nodes of the stack.
*
*     RETURNS         : SUCCESS if memory is freed,
*                       FAILURE if stack is already empty
*
*******************************************************************************/
int free_stack(node **top) 
{
    node *current; /* Temporary node pointer to traverse the stack */

    /* Check if the stack is already empty i.e. does not exist */
    if (isempty(*top))
    {
        return FAILURE;
    }
    /* Traverse the stack to free each node */
    while (NULL != *top)
    {
        current = (*top)->next;
        free(*top);
        *top = current;
    }
    
    return SUCCESS;
}

