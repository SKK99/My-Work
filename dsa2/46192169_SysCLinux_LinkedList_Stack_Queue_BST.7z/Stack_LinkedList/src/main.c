/*******************************************************************************
*
*     FILENAME       :    main.c
*
*     DESCRIPTION    :    This file defines the main function.
*       It is used for performing different operations on a queue.
*
*     Revision History    :
*     DATE              NAME                  REFERENCE            REASON
*     ----------------------------------------------------------
*     09-03-2022        Shankar Karn            Main Function       Stack with linked list
*     Copyright @ 2022 Capgemini  All Rights Reserved
*
*******************************************************************************/

#include "header.h"
/******************************************************************************
*
*     FUNCTION NAME   :    main
*
*     DESCRIPTION     :    This function calls different functions to perform
*                          operations like push, pop, display etc on
*                          a stack.
*
*     RETURNS         : SUCCESS
*
*******************************************************************************/
int main(void)
{
    node *top= NULL; /* Pointer for the top of the stack */
    int status; /* Variable to check the return status */
    int choice;  /* variable to take the user choice */

    /*Take the user's choice and invoke the function to perform an operation on the stack */
    do
    {
        printf("\nPlease enter your choice \n");
        printf("\n1.Push \n");
        printf("2.Pop \n");
        printf("3.Display\n");
        printf("4.Peep\n");
        printf("5.Exit \n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1: 
                        /* Perform insertion in the stack */
                        printf("\nenter the value to be inserted ");
                        int num; /* variable to take the input from user */
                        scanf("%d",&num);
                        push(&top , num);
                        break;
            case 2: 
                         /* Perform deletion on the stack */
                        status = pop(&top);

                        /* Check the value returned from the function */
                        if (FAILURE == status)
                        {
                            printf("\nYou cannot delete");
                        }
                        else
                        {
                            printf("\nElement popped successfully");
                        }
                        break;
                    
            case 3: 
                         /* Display the stack contents */
                        display(&top);
                        break;
                    
            case 4: 
                         /* Perform deletion on the stack */
                        status = peep(&top);

                        /* Check the value returned from the function */
                        if (FAILURE == status)
                        {
                            printf("\nYou cannot look at top element");
                        }
                        else
                        {
                            printf("\nTop Element viewed successfully");
                        }
			break;
	   case 5:
			printf("\nThank You !\n");
			break;
	   default:
			printf("\nPlease enter the right choice\n");
        }
    }while(choice !=5);

    /* Free the memory allocated to the stack */
    status = free_stack(&top);
    if (SUCCESS == status)
    {
        printf("\nMemory freed\n");
    }
    else
    {
        printf("\nMemory not freed\n");
    }

    return SUCCESS;
}
