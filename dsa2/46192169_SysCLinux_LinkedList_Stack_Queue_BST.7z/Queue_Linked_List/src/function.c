/*******************************************************************************
*
*     FILENAME       :    functions.c
*
*     DESCRIPTION    :    This file defines the various functions on queue.
*
*     Revision History    :
*     DATE              NAME                  REFERENCE            REASON
*     ----------------------------------------------------------
*     09-03-2022        Shankar Karn        Function Definition     Queue using Linked List
*
*******************************************************************************/

#include "header.h"

/******************************************************************************
*
*     FUNCTION NAME   :   isempty
*
*     DESCRIPTION     :   This function checks whether the queue is empty or not
*
*     RETURNS         : SUCCESS, if queue is empty
*                       FAILURE, if queue is not empty
*
*******************************************************************************/
int isempty(node *front) /* Parameter for the front end of the Queue */
{
    if (NULL == front)
    {
        return SUCCESS;
    }
    else
    {
        return FAILURE;
    }
}

/******************************************************************************
*
*     FUNCTION NAME   : enqueue
*
*     DESCRIPTION     :This function inserts a new node at the rear end of the  *		       queue
*
*     RETURNS         : void
*
*******************************************************************************/
void enqueue(node **front, node ** rear,int value)
{
    /* Node pointer for the new node which needs to be inserted */
    node *newnode;

    /* Allocate memory to the new node */
    newnode = (node*) malloc (sizeof(node));

    /* Check if memory is allocated or not */
    if (NULL ==newnode)
    {
        printf("Memory not available");
        exit(FAILURE);
    }

    /* Insert the new node in the queue */
    newnode->data = value;
    newnode->next = NULL;

       /* Check whether queue is empty or not */
    if (isempty(*front))
    {
        /* This is the first node */
       *front = newnode;
       *rear = newnode;
    }
    else
    {
        /* Node's exist in the queue so insert at the rear end */
        (*rear)->next = newnode;
        *rear = newnode;
    }

}

/******************************************************************************
*
*     FUNCTION NAME   : dequeue
*
*     DESCRIPTION     :  This function deletes a node from the front end of the *			queue
*
*     RETURNS         : SUCCESS, if element is deleted
*			FAILURE, if queue is empty
*
*******************************************************************************/
int dequeue(node **front, node **rear)
{
    /* Temporary node pointer */
    node *temp_node; 
    /* Variable to represent the data which is deleted */
    int value; 
    
    /* Check if the queue is empty or not */     
    if (isempty(*front))
    {
        printf("\nQueue Underflow");
        return FAILURE;
    }

    if (*rear == *front)
    {
        /* Only one node is available in the queue */
        temp_node = *front;
        *front = NULL;
        *rear =NULL;
    }        
    else
    {
        /* Delete the node from the front end of the queue */
        temp_node = *front;
        *front = (*front)->next;
    }

    value = temp_node->data;
    free (temp_node);
    printf("\nElement deleted is %d",value);
    return SUCCESS;
}

/******************************************************************************
*
*     FUNCTION NAME   :    display
*
*     DESCRIPTION     :This function displays the data in the queue
*
*     RETURNS         : nothing
*
*******************************************************************************/
void display(node **front)
{
    /* Temporary node pointer to traverse the queue */
    node *current; 

    /* Check if the queue is empty or not */
    if (isempty(*front))
    {
        printf("\nThe Queue is empty") ;
    }
    else
    {
        printf("\nQueue is \n");
  
        /* Traverse the queue and display the elements */
        for( current = *front ; current != NULL ; current = current->next)
        {
            printf("%d -> ",current->data);
        }
        printf("NULL\n");
    }
}

/******************************************************************************
*
*     FUNCTION NAME   :    free_queue
*
*     DESCRIPTION     :    This function frees the memory which is allocated to
*                       the nodes of the queue.
*
*     RETURNS         : SUCCESS if memory is freed,
*                       FAILURE if queue is already empty
*
*******************************************************************************/
int free_queue(node **front, node **rear)
{
    /* Temporary node pointer to traverse the queue */
    node *current; 

    /* Check if the queue is already empty i.e. does not exist */
    if (isempty(*front))
    {
        return FAILURE;
    }
    /* Traverse the queue to free each node */
    while (*front != NULL)
    {
        current = (*front)->next;
        free(*front);
        *front = current;
    }
    
    *rear= NULL;
    return SUCCESS;
}

