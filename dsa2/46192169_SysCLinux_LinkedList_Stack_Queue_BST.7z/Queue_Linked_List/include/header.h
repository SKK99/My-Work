/*******************************************************************************
*
*     FILENAME       :    header.h
*
*     DESCRIPTION    :    This file defines the macros and the structure of the
*                       node used for the queue.
*
*     Revision History    :
*     DATE              NAME                  REFERENCE            REASON
*     ----------------------------------------------------------
*     09-03-2022        Shankar Karn            Header File         Queue is Linked List
*     Copyright @ 2022 Capgemini  All Rights Reserved
*
*******************************************************************************/

/********************** Header File Inclusions ********************************/
#include <stdio.h>
#include<stdlib.h>

/********************** Macro definitions *************************************/
# define SUCCESS 1
# define FAILURE 0

/********************** Structure Definition **********************************/
typedef struct node_q
{
    int data;
    struct node_q *next;
}node;

/********************** Function Declaration **********************************/
void enqueue(node **,node **,int);
int dequeue(node **,node **);
int isempty(node *);
void display(node **);
int free_queue(node** , node**);

