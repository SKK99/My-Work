/************************************************************************
*    FILENAME     : main.c
*    DESCRIPTION  : Read data from input file, stores in Hash Table 
*                   resolves collision using chaining method and displays 
*                   contents of Hash Table
*    DATE	NAME            REFERENCE       REASON
*    --------------------------------------------------
***************************************************************************/
#include"header.h"

/***************************************************************************
*    FUNCTION NAME : main
*    DESCRIPTION   : open the files for input creates hash table
*		     make the output file and write the content of hash table 
*		     and  free the hash table
*    RETURNS       : SUCCESS/FAILURE 
***************************************************************************/
int main(int argc,
	 char *argv[])
{
    FILE *in_file, /*input file*/
	 *out_file; /*output file */

    HT_node *hash_table[HASH_TABLE_SIZE]; /*hash table*/
    int ret_val;

    if (argc != 3)
    {
	printf("Number of Command Line Arguments not correct\n");
	fprintf(stderr, "Usage: <a.out> <source file> <dest file>\n");
	return FAILURE;
    }

    ret_val = Fopen(&in_file,argv[1],"r");
    if (ret_val == FAILURE)
    {
	printf("Opening of File %s falied\n", argv[1]);
	return FAILURE;
    }

    /*initialize the hash table index */
    memset(hash_table, 0, HASH_TABLE_SIZE * sizeof(HT_node *));

    ret_val =  read_file(in_file, hash_table);
	
   /* if reading from file was not complete then failure will be returned */
    if(FAILURE == ret_val)
    {
	free_hash(hash_table);
	return FAILURE;
    }
	
    ret_val = Fclose(&in_file);
    if(FAILURE == ret_val)
    {
        printf("Closing of File %s falied\n", argv[1]);
	free_hash(hash_table);
	return FAILURE;
    }
	
    ret_val = Fopen(&out_file,argv[2],"w");
    if (ret_val == FAILURE)
    {
	printf("Opening of File %s falied\n", argv[2]);
	free_hash(hash_table);
	return FAILURE;
    }

/*words from file are read into the hash table with there respective count*/

    ret_val = write_file(out_file, hash_table);
    if(FAILURE == ret_val)
    {
	free_hash(hash_table);
	return FAILURE;
    }

	/*write to file successful*/
	/*files need to be closed*/
    ret_val = Fclose(&out_file);
    if(FAILURE == ret_val)
    {
        printf("Closing of File %s falied\n", argv[2]);
	free_hash(hash_table);
	return FAILURE;
    }
	
    ret_val = free_hash(hash_table);

    printf("%s created\n",argv[2]);
		
    return SUCCESS;
}

