/***********************************************************************
*    FILENAME    : functions.c
*    DESCRIPTION : contains functions to open file, close file, read file 
*                  search hash table, write file, hash function 
*                  and  free the hash table
*
*    DATE         NAME          REFERENCE        REASON
*    -----------------------------------------------------
***************************************************************************/

/**************************HEADER FILE**************************************/
#include"header.h"

/*************************LOCAL MACROS**************************************/
#define IN
#define OUT
#define MODI

/************************FUNCTION DEFINITIONS******************************/

/**************************************************************************
*    	FUNCTION NAME  	: Fopen
*    	DESCRIPTION    	: Opens the file, If not found returns error
*	RETURN 		: SUCCESS/FAILURE
**************************************************************************/
int Fopen(OUT FILE **fptr,
	  IN  char *filename,
	  IN char *mode)
{
	*fptr = fopen(filename,mode);

	if (NULL == (*fptr))
	{
	  return FAILURE;
	}

	return SUCCESS;
}

/**************************************************************************
*    	FUNCTION NAME  	: Fclose
*    	DESCRIPTION    	: Closes the file, If not found returns error
*	RETURN 		: SUCCESS/FAILURE
**************************************************************************/
int Fclose(IN FILE **fptr)
{
	int ret = 0;

	ret = fclose(*fptr);
	if (ret != 0)
	{
	   return FAILURE;
	}
	return SUCCESS;
}

/**************************************************************************
*    	FUNCTION NAME  	: read_file
*    	DESCRIPTION    	: Reads the file for each word and store in hash table*                         with frequency
*	RETURN 		: SUCCESS/FAILURE
**************************************************************************/
int read_file(IN FILE *fptr,
	      OUT HT_node **hash_table) 
{
	char str[MAX];
	int key = 0;
	HT_node *ret_node;  /*address of the node to be searched */

        memset(str, 0, MAX);

	while (EOF != fscanf(fptr,"%s",str))
	{
	    key = hash_function(str);
	    ret_node = search_node(key,str,hash_table);

	    /*word is not in the hash table , new node is to be inserted*/

	    if(NULL == ret_node)
	    {
	      /*new node made with default count 1 */
	      ret_node = addnew_node(str);

			/* insert at begining */
	      if(NULL == ret_node)
	      {
		/* new node could not be created as memory error */
		return FAILURE;
	      }

	      if (NULL == hash_table[key])
	      {
		hash_table[key] = ret_node;
	      }
	      else
	      {
	        /***********collision handling *****************************/
		ret_node->next = hash_table[key];
		hash_table[key] = ret_node;
	      }
	    }
	    else  /* increment the frequency by 1 */
	    {
		ret_node->count += 1;
	    }

            memset(str, 0, MAX);
	}
	return SUCCESS;
}

/**************************************************************************
*    	FUNCTION NAME  	: write_file
*    	DESCRIPTION    	: Reads the hash table and store words with frequency
*	RETURN 		: SUCCESS/FAILURE
**************************************************************************/
int write_file(IN FILE *fptr,
	       IN HT_node **hash_table)
{
	int index = 0;
	int ret = 0;
	HT_node *curr = NULL;
	for(index = 0; index < HASH_TABLE_SIZE; index += 1)
	{
	   for(curr = hash_table[index]; NULL != curr; curr = curr->next)
	   {
		ret = fprintf(fptr,"%s %d\n",curr->str,curr->count);
		if (ret < 0)
		{
		   return FAILURE;
		}
	   }
	}

	return SUCCESS;
}

/**************************************************************************
*    	FUNCTION NAME  	: hash_function
*    	DESCRIPTION    	: Calculates index value 
*	RETURN 		: SUCCESS/FAILURE
**************************************************************************/
int hash_function(IN char *str)
{
	int index = 0;
	int str_len = strlen(str);
	int sum = 0;
	for(index  = 0; index < str_len; index += 1)
	{
		sum += str[index];
	}

	return sum % HASH_TABLE_SIZE;
}

/**************************************************************************
*     	FUNCTION NAME : addnew_node
*	DESCRIPTION   : Creates a new node
*	RETURN        : address of new node (node*)
**************************************************************************/
HT_node* addnew_node(IN char *str)
{
	HT_node *new = NULL;

	new = (HT_node *) calloc(1, sizeof(HT_node));
	if (NULL == new)
	{
           printf("Memory Allocation Failure\n");
	   return NULL;
	}
	
	new->str = (char *) calloc(strlen(str)+1,sizeof(char));
	if(NULL == new->str)
	{
           printf("Memory Allocation Failure\n");
	   free(new);
	   return NULL;
	}
	
	strcpy(new->str,str);
	new->count = 1;
	new->next = NULL;

	return new;
}

/*************************************************************************
*     	FUNCTION NAME : search_node
*	DESCRIPTION   : searches hash table for input word 
*	RETURN        : address of node found or NULL 
**************************************************************************/
HT_node* search_node(IN int key,
                     IN char *str,
		     IN HT_node **hash_table)
{
     HT_node *temp =  NULL;

     for(temp = hash_table[key]; NULL != temp; temp = temp->next)
     {
	if (0==strcmp(temp->str,str)) //match found
	{
	   break;
	}
     }

     return temp;
}


/*************************************************************************
*     	FUNCTION NAME : free_hash
*	DESCRIPTION   : frees  hash table for allocated memoey 
*	RETURN        : SUCCESS/FAILUER 
**************************************************************************/
int free_hash(MODI HT_node **hash_table)
{
	int index = 0;
	HT_node *temp = NULL;
	for(index = 0; index < HASH_TABLE_SIZE; index += 1)
	{
	    while(NULL != hash_table[index])
	    {
		temp = hash_table[index];
		hash_table[index] = temp->next;
		free(temp->str);
		temp->str = NULL;
		free(temp);
		temp = NULL;
	    }	
	}

	return SUCCESS;
}

